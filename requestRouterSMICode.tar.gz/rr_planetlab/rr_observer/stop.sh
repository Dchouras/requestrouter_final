pkill -9 -f rr-backend.py
