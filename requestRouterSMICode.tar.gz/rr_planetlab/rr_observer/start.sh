nohup python rr-backend.py  -C /opt/planetstack/rr_observer/rr_observer_config > /dev/null 2>&1 &
